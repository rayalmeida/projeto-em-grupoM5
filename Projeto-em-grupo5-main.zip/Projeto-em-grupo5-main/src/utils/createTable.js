const User = require("../models/User");

User.sync();
